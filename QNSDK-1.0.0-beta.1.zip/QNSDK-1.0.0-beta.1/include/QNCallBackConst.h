
//
//  QNCallBackConst.h
//  QNDeviceSDKDemo
//
//  Created by Yolanda on 2018/3/31.
//  Copyright © 2018年 Yolanda. All rights reserved.
//

typedef void(^QNResultCallback) (NSError *error);
typedef void(^QNObjCallback) (id obj, NSError *error);
